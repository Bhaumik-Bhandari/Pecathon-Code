
import { useEffect, useState } from "react";
import {
  ArrowUpRight,
  ImageUp,
  Orbit,
  Rocket,
  RotateCcw,
  Satellite,
  ScanSearch,
  SkipForward,
  Sparkles,
} from "lucide-react";

/*
 * PECFEST 2026 — THE SPIRIT LENS
 *
 * Scene 1: Rocket launch from Earth.
 * Scene 2: Enter deep space.
 * Scene 3: Travel across an illustrative planetary route.
 *
 * Existing JPEG/PNG upload and image preview functionality
 * remains available below the cinematic scene.
 *
 * Note: planetary positions and route are visual mock data.
 * NASA data and restoration APIs are not connected here.
 */

const PLANETS = [
  {
    id: "earth",
    name: "Earth",
    subtitle: "The homeworld",
    location: "ORIGIN POINT",
    description:
      "Every great journey begins somewhere. Your expedition departs from Earth.",
    stat: "HOME",
    className: "earth",
    x: 10.5,
    y: 58,
  },
  {
    id: "moon",
    name: "The Moon",
    subtitle: "Our nearest celestial neighbor",
    location: "LUNAR OUTPOST",
    description:
      "A nearby destination for exploring craters, lunar terrain and our closest celestial neighbor.",
    stat: "SATELLITE",
    className: "moon",
    x: 29,
    y: 28,
  },
  {
    id: "mars",
    name: "Mars",
    subtitle: "The red planet",
    location: "FRONTIER 01",
    description:
      "A rust-colored world with ancient terrain, enormous volcanoes and a history written in dust.",
    stat: "TERRESTRIAL",
    className: "mars",
    x: 48,
    y: 62,
  },
  {
    id: "jupiter",
    name: "Jupiter",
    subtitle: "The giant of the solar system",
    location: "FRONTIER 02",
    description:
      "A colossal gas giant with turbulent atmospheric bands and a remarkable family of moons.",
    stat: "GAS GIANT",
    className: "jupiter",
    x: 69,
    y: 29,
  },
  {
    id: "saturn",
    name: "Saturn",
    subtitle: "The world of rings",
    location: "FRONTIER 03",
    description:
      "A magnificent ringed giant and a dramatic destination for the next stage of your journey.",
    stat: "RINGED GIANT",
    className: "saturn",
    x: 88,
    y: 55,
  },
];

function LaunchRocket() {
  return (
    <svg
      className="spirit-launch-rocket-art"
      viewBox="0 0 100 160"
      role="img"
      aria-label="Rocket lifting off from Earth"
    >
      <defs>
        <linearGradient id="spirit-rocket-body" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#BFC5CE" />
          <stop offset="32%" stopColor="#FFF8E8" />
          <stop offset="70%" stopColor="#F2E9DB" />
          <stop offset="100%" stopColor="#9299A4" />
        </linearGradient>
        <linearGradient id="spirit-rocket-fire" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#FFF4B2" />
          <stop offset="45%" stopColor="#F5A640" />
          <stop offset="100%" stopColor="#D94C42" stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* Engine plume */}
      <path
        className="spirit-rocket-flame"
        d="M39 101 L50 151 L61 101 Z"
        fill="url(#spirit-rocket-fire)"
      />

      <path
        className="spirit-rocket-flame-inner"
        d="M45 102 L50 133 L55 102 Z"
        fill="#FFF2BE"
      />

      {/* Left fin */}
      <path
        d="M37 84 L19 111 L38 104 L44 83 Z"
        fill="#B94336"
      />

      {/* Right fin */}
      <path
        d="M63 84 L81 111 L62 104 L56 83 Z"
        fill="#D94C42"
      />

      {/* Main hull */}
      <path
        d="M50 8 C43 20 34 32 32 53 L32 98 Q50 111 68 98 L68 53 C66 32 57 20 50 8 Z"
        fill="url(#spirit-rocket-body)"
        stroke="#E9B15D"
        strokeWidth="1.4"
      />

      {/* Nose highlight */}
      <path
        d="M50 8 C43 20 38 28 36 39 L50 34 L64 39 C62 28 57 20 50 8 Z"
        fill="#FFFFFF"
        opacity=".8"
      />

      {/* Window */}
      <circle
        cx="50"
        cy="54"
        r="10"
        fill="#101A2A"
        stroke="#D9B777"
        strokeWidth="3"
      />
      <circle
        cx="47"
        cy="51"
        r="3"
        fill="#A6D7F0"
        opacity=".9"
      />

      {/* Hull details */}
      <path
        d="M35 76 H65"
        stroke="#C6A568"
        strokeWidth="2"
      />
      <path
        d="M35 83 H65"
        stroke="#C6A568"
        strokeWidth="1"
        opacity=".6"
      />

      {/* Engine housing */}
      <path
        d="M39 98 H61 L58 108 H42 Z"
        fill="#777F8A"
        stroke="#E9B15D"
        strokeWidth="1"
      />
    </svg>
  );
}

function PlanetNode({ planet, selected, onSelect }) {
  return (
    <button
      type="button"
      className={[
        "spirit-planet-node",
        `spirit-planet-node--${planet.className}`,
        selected ? "is-selected" : "",
      ].join(" ")}
      style={{
        left: `${planet.x}%`,
        top: `${planet.y}%`,
      }}
      onClick={() => onSelect(planet.id)}
      aria-pressed={selected}
      aria-label={`Select ${planet.name}`}
    >
      <span className="spirit-planet-visual">
        <span className="spirit-planet-surface" />
        {planet.id === "saturn" && (
          <span className="spirit-planet-rings" />
        )}
      </span>

      <span className="spirit-planet-label">
        {planet.name}
      </span>

      <span className="spirit-planet-subtitle">
        {planet.location}
      </span>
    </button>
  );
}

export default function SpiritLens() {
  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState("");
  const [error, setError] = useState("");

  const [scene, setScene] = useState("launch");
  const [launchRun, setLaunchRun] = useState(0);
  const [selectedPlanet, setSelectedPlanet] = useState("earth");

  /*
   * Launch automatically transitions to the planetary scene.
   * A Skip control is available so users do not have to wait.
   */
  useEffect(() => {
    if (scene !== "launch") return;

    if (
      window.matchMedia?.("(prefers-reduced-motion: reduce)").matches
    ) {
      setScene("orbit");
      return;
    }

    const timer = window.setTimeout(() => {
      setScene("orbit");
    }, 7300);

    return () => window.clearTimeout(timer);
  }, [scene, launchRun]);

  /*
   * Create a temporary local URL for the uploaded image.
   * The URL is revoked when the image changes or the page
   * unmounts to avoid leaving unused object URLs behind.
   */
  useEffect(() => {
    if (!file) {
      setPreviewUrl("");
      return;
    }

    const url = URL.createObjectURL(file);
    setPreviewUrl(url);

    return () => URL.revokeObjectURL(url);
  }, [file]);

  function handleFileChange(event) {
    const selectedFile = event.target.files?.[0];

    setError("");
    setFile(null);

    if (!selectedFile) return;

    const supportedTypes = ["image/jpeg", "image/png"];

    if (!supportedTypes.includes(selectedFile.type)) {
      setError("Please select a JPEG or PNG image.");
      event.target.value = "";
      return;
    }

    if (selectedFile.size > 10 * 1024 * 1024) {
      setError("The image must be smaller than 10 MB.");
      event.target.value = "";
      return;
    }

    setFile(selectedFile);
  }

  function replayLaunch() {
    setSelectedPlanet("earth");
    setLaunchRun((run) => run + 1);
    setScene("launch");
  }

  function skipLaunch() {
    setScene("orbit");
  }

  const activePlanet =
    PLANETS.find((planet) => planet.id === selectedPlanet) ??
    PLANETS[0];

  return (
    <section className="spirit-lens-page space-y-7">

      {/* MODULE HEADING — EXISTING CONTENT RETAINED */}
      <header>
        <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#E9B15D]">
          Module 03 · The Spirit Lens
        </p>

        <h1 className="mt-3 text-3xl font-bold text-[#F2E9DB]">
          Reveal the details hidden in the stars.
        </h1>

        <p className="mt-3 max-w-2xl text-sm leading-6 text-slate-400">
          Preview an astronomical image before connecting it
          to the image-restoration and source-detection pipeline.
        </p>
      </header>

      {/* ==================================================
          CINEMATIC LAUNCH + PLANETARY ROUTE
          ================================================== */}

      <section
        key={launchRun}
        className={`spirit-stage spirit-stage--${scene}`}
        aria-label="Spirit Lens space expedition"
      >
        <div className="spirit-nebula" aria-hidden="true" />
        <div className="spirit-starfield spirit-starfield--far" aria-hidden="true" />
        <div className="spirit-starfield spirit-starfield--near" aria-hidden="true" />

        {/* TOP MISSION HUD */}
        <div className="spirit-stage-hud">
          <div className="spirit-mission-brand">
            <span className="spirit-mission-emblem">
              <Orbit size={18} />
            </span>
            <div>
              <p>SPIRIT LENS</p>
              <span>DEEP SPACE EXPLORATION</span>
            </div>
          </div>

          <div className="spirit-mission-status">
            <span className="spirit-live-dot" />
            {scene === "launch" ? "LAUNCH SEQUENCE" : "IN ORBIT"}
          </div>
        </div>

        {/* SCENE ONE — EARTH AND LIFTOFF */}
        {scene === "launch" && (
          <div className="spirit-launch-scene">
            <div className="spirit-launch-copy">
              <p className="spirit-scene-eyebrow">
                MISSION 001 · DEPARTURE
              </p>
              <h2>
                Beyond the
                <br />
                <span>known sky.</span>
              </h2>
              <p>
                Leaving Earth behind.
                <br />
                Beginning the search for the extraordinary.
              </p>
            </div>

            <div className="spirit-launch-coordinates" aria-hidden="true">
              <span>ORIGIN: EARTH</span>
              <span>DESTINATION: THE COSMOS</span>
              <span>STATUS: INITIATING</span>
            </div>

            <div className="spirit-atmosphere" aria-hidden="true" />

            <div className="spirit-earth" aria-hidden="true">
              <div className="spirit-earth-clouds" />
              <div className="spirit-earth-lights" />
              <div className="spirit-earth-rim" />
            </div>

            <div className="spirit-launch-burst" aria-hidden="true" />

            <div className="spirit-rocket-launching">
              <LaunchRocket />
            </div>

            <div className="spirit-launch-exhaust" aria-hidden="true" />

            <div className="spirit-launch-bottom">
              <span className="spirit-launch-dot" />
              <span>ENGINES IGNITED</span>
              <span className="spirit-launch-separator">/</span>
              <span>BREAKING EARTH ORBIT</span>
            </div>

            <button
              type="button"
              className="spirit-scene-control"
              onClick={skipLaunch}
            >
              Skip launch
              <SkipForward size={15} />
            </button>
          </div>
        )}

        {/* SCENE TWO — DEEP SPACE AND THE PLANETARY ROUTE */}
        {scene === "orbit" && (
          <div className="spirit-orbit-scene">

            <div className="spirit-orbit-heading">
              <p className="spirit-scene-eyebrow">
                EXPEDITION MAP · SOLAR SYSTEM
              </p>
              <h2>
                The universe
                <span> awaits.</span>
              </h2>
              <p>
                Select a world to inspect your next destination.
              </p>
            </div>

            {/* Decorative orbit lines */}
            <svg
              className="spirit-orbit-path"
              viewBox="0 0 1000 500"
              preserveAspectRatio="none"
              aria-hidden="true"
            >
              <defs>
                <linearGradient id="spirit-route-gradient">
                  <stop offset="0%" stopColor="#E9B15D" stopOpacity=".22" />
                  <stop offset="48%" stopColor="#E9B15D" stopOpacity=".78" />
                  <stop offset="100%" stopColor="#A7CFF5" stopOpacity=".28" />
                </linearGradient>
              </defs>

              <path
                className="spirit-route-glow"
                d="M105 290 C155 125 220 80 290 140 C360 185 425 350 480 310 C550 245 615 70 690 145 C755 210 820 350 880 275"
              />

              <path
                className="spirit-route-line"
                d="M105 290 C155 125 220 80 290 140 C360 185 425 350 480 310 C550 245 615 70 690 145 C755 210 820 350 880 275"
                stroke="url(#spirit-route-gradient)"
              />
            </svg>

            {/* Selectable planetary markers */}
            <div className="spirit-planet-field">
              {PLANETS.map((planet) => (
                <PlanetNode
                  key={planet.id}
                  planet={planet}
                  selected={selectedPlanet === planet.id}
                  onSelect={setSelectedPlanet}
                />
              ))}
            </div>

            {/* Tiny rocket travelling along the route */}
            <div className="spirit-route-rocket" aria-hidden="true">
              <Rocket size={25} strokeWidth={1.6} />
              <span />
            </div>

            <div className="spirit-route-caption">
              <Satellite size={14} />
              <span>MISSION TRAJECTORY</span>
              <i />
              <span>ILLUSTRATIVE ROUTE</span>
            </div>

            <button
              type="button"
              className="spirit-scene-control"
              onClick={replayLaunch}
            >
              <RotateCcw size={14} />
              Replay launch
            </button>
          </div>
        )}
      </section>

      {/* SELECTED PLANET DETAILS */}
      <section className="spirit-destination-panel">
        <div className="spirit-destination-marker">
          <span className={`spirit-destination-orb spirit-destination-orb--${activePlanet.className}`}>
            <span />
          </span>
        </div>

        <div className="spirit-destination-copy">
          <p className="spirit-destination-kicker">
            CURRENT SELECTION · {activePlanet.location}
          </p>
          <h2>{activePlanet.name}</h2>
          <p>{activePlanet.description}</p>
        </div>

        <div className="spirit-destination-meta">
          <span>DESTINATION TYPE</span>
          <strong>{activePlanet.stat}</strong>
          <small>DEMO ROUTE · NOT TO SCALE</small>
        </div>
      </section>

      {/* ==================================================
          ORIGINAL UPLOAD AND PREVIEW FUNCTIONALITY
          ================================================== */}

      <section className="rounded-2xl border border-white/10 bg-[#152234]/80 p-5 sm:p-7">
        <div className="flex items-center gap-3">
          <ImageUp size={22} className="text-[#E9B15D]" />

          <div>
            <h2 className="font-semibold text-[#F2E9DB]">
              Upload an astronomy image
            </h2>
            <p className="mt-1 text-xs text-slate-400">
              JPEG or PNG · Maximum 10 MB
            </p>
          </div>
        </div>

        <label className="mt-6 flex min-h-[180px] cursor-pointer flex-col items-center justify-center rounded-xl border border-dashed border-white/20 bg-[#0D1725]/60 p-6 text-center transition hover:border-[#E9B15D]/60">
          <ImageUp size={34} className="text-[#E9B15D]" />

          <span className="mt-4 font-medium text-[#F2E9DB]">
            Choose an image from your computer
          </span>

          <span className="mt-2 text-sm text-slate-400">
            Your original image will remain unchanged.
          </span>

          <input
            type="file"
            accept="image/jpeg,image/png"
            className="sr-only"
            onChange={handleFileChange}
          />
        </label>

        {error && (
          <p role="alert" className="mt-4 text-sm text-red-400">
            {error}
          </p>
        )}

        {previewUrl && (
          <div className="mt-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h3 className="font-medium text-[#F2E9DB]">
                Original image preview
              </h3>

              <span className="text-xs text-slate-400">
                {(file.size / (1024 * 1024)).toFixed(2)} MB
              </span>
            </div>

            <div className="mt-4 overflow-hidden rounded-xl border border-white/10 bg-black">
              <img
                src={previewUrl}
                alt="Selected astronomical image"
                className="mx-auto max-h-[480px] w-full object-contain"
              />
            </div>

            <p className="mt-3 break-all text-xs text-slate-400">
              {file.name}
            </p>
          </div>
        )}
      </section>

      {/* EXISTING RESTORATION AND DETECTION CARDS */}
      <div className="grid gap-4 sm:grid-cols-2">
        <section className="rounded-2xl border border-white/10 bg-[#152234]/80 p-5">
          <Sparkles size={22} className="text-[#E9B15D]" />

          <h2 className="mt-4 font-semibold text-[#F2E9DB]">
            AI image restoration
          </h2>

          <p className="mt-2 text-sm leading-6 text-slate-400">
            The pre-trained restoration model and backend
            processing pipeline have not been connected yet.
          </p>

          <div className="mt-4 flex items-center gap-2 text-xs text-[#E9B15D]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#E9B15D]" />
            Awaiting backend integration
          </div>
        </section>

        <section className="rounded-2xl border border-white/10 bg-[#152234]/80 p-5">
          <ScanSearch size={22} className="text-[#E9B15D]" />

          <h2 className="mt-4 font-semibold text-[#F2E9DB]">
            Object detection
          </h2>

          <p className="mt-2 text-sm leading-6 text-slate-400">
            Detected-object markers and image measurements
            will appear after a scan is processed by the backend.
          </p>

          <div className="mt-4 flex items-center gap-2 text-xs text-[#E9B15D]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#E9B15D]" />
            Awaiting backend integration
          </div>
        </section>
      </div>

      {/* Keep a subtle action hint for the next stage. */}
      <p className="flex items-center gap-2 text-xs text-slate-500">
        <ArrowUpRight size={14} />
        The expedition scene is a visual introduction. NASA data and the
        Spirit Lens processing pipeline will be connected separately.
      </p>
    </section>
  );
}
